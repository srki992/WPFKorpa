﻿using Aplikacija.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Aplikacija.UnitTests
{
    [TestClass]
    public class PodaciServiceTests
    {
        [TestMethod]
        public void GetAll_ReturnsAllAvailableItems_ReturnEqual()
        {
            //Arrange
            var podaciService = new PodaciService();
            //Act
            var result = podaciService.GetAll();
            //Assert
            Assert.AreEqual(GetSampleListArticles().Count, result.Count);
        }
        [TestMethod]
        public void DodajStavkuURacun_DodataNovaStavka_ReturnEqual()
        {
            //Arrange
            var podaciService = new PodaciService();
            //Act
            ObservableCollection<StavkaRacuna> stavkaRacuna = new ObservableCollection<StavkaRacuna>();
            var result = podaciService.DodajStavkuURacun(stavkaRacuna, new StavkaRacuna { ime = "TestArtikal", kolicina = 1, cena = 2.75, valuta = "$" });
            //Assert
            Assert.AreEqual(1, result.Count);
        }

        [TestMethod]
        public void ObrisiStavkuSaRacuna_UkloniStavku_ReturnEqual()
        {
            //Arrange
            var podaciService = new PodaciService();
            //Act
            var result = podaciService.ObrisiStavkuSaRacuna(ListaArtikalaUKorpi(), new StavkaRacuna { ime = "Mleko", cena = 1.15, valuta = "$", kolicina = 1 });
            //Assert
            Assert.AreEqual(3, result.Count);
        }
        private ObservableCollection<StavkaRacuna> ListaArtikalaUKorpi()
        {
            ObservableCollection<StavkaRacuna> output = new ObservableCollection<StavkaRacuna>
            {
                new StavkaRacuna
                {
                    ime = "Mleko", cena = 1.15, valuta = "$", kolicina = 1
                },
                new StavkaRacuna
                {
                    ime = "Hleb", cena = 1.00, valuta = "$", kolicina = 1
                },
                new StavkaRacuna
                {
                    ime = "Puter", cena = 0.80, valuta = "$", kolicina = 1
                }
            };
            return output;
        }
        private List<Artikal> GetSampleListArticles()
        {
            List<Artikal> output = new List<Artikal>
            {
                new Artikal
                {
                    ime = "Mleko", cena = 1.15, valuta = "$"
                },
                new Artikal
                {
                    ime = "Hleb", cena = 1.00, valuta = "$"
                },
                new Artikal
                {
                    ime = "Puter", cena = 0.80, valuta = "$"
                }
            };
            return output;
        }
    }
}
